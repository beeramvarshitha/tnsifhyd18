package ipl;
	public class Srh {
		 public void batsman() {
			System.out.println("Rahul tripathi");
		}
		public void bowler() {
			System.out.println("Akash singh");
		}
		public void allrounder() {
			System.out.println("Abhishek Sharama");
		}
	}


