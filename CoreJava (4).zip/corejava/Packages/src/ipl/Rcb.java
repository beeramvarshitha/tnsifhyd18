package ipl;

public class Rcb {
		
		public void batsman() {
			System.out.println("Dinesh Karthik");
		}
		public void bowler() {
			System.out.println("Rajan Kumar");
		}
		public void allrounder() {
			System.out.println("Karn Sharma");
		}
	}
	

