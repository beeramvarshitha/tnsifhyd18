package ipl;

public class Csk {
	

	public void batsman() {
		System.out.println("M.S.Dhoni");
	}
	public void bowler() {
		System.out.println("mukesh Choudhary");
	}
	public void allrounder() {
		System.out.println("Ravindra Jadeja");
	}
}
