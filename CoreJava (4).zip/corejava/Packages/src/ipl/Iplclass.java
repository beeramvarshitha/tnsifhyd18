package ipl;
import ipl.*;
public class Iplclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Csk c1=new Csk();
		Rcb r1=new Rcb();
		Srh s1=new Srh();
		System.out.println("Csk team:");
		c1.batsman();
		c1.bowler();
		c1.allrounder();
		System.out.println("Rcb team:");
		r1.batsman();
		r1.bowler();
		r1.allrounder();
		System.out.println("Srh team:");
		s1.batsman();
		s1.bowler();
		s1.allrounder();
	}

}
