package com.java.org;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Insert {
	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/employeedb";
		String username = "root";
		String password = "Varshitha186";
		 
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		    String sql = "INSERT INTO Employee (id,name,department,experience) VALUES (?, ?, ?, ?)";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setString(1, "123");
		    statement.setString(2, "venkat");
		    statement.setString(3, "marketing");
		    statement.setString(4, "3years");
		    
		   /* statement.setString(1, "311");
		    statement.setString(2, "vijay");
		    statement.setString(3, "accounting");
		    statement.setString(4, "2years");
		    
		    statement.setString(1, "412");
		    statement.setString(2, "shobha");
		    statement.setString(3, "public relations");
		    statement.setString(4, "1years");
		    
		    statement.setString(1, "523");
		    statement.setString(2, "pushpa");
		    statement.setString(3, "research and development");
		    statement.setString(4, "4years");*/
		    


		    int rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0) {
		        System.out.println("A new user was inserted successfully!");
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
	}
	
}

