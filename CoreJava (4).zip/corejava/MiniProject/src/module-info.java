/**
 * 
 */
/**
 * 
 */
module MiniProject {
	requires java.sql;
}