package com.ab.in;

import java.util.HashSet;
import java.util.Iterator;

public class Hashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    HashSet<String>hs=new HashSet<String>();
    hs.add("Greeks");
    hs.add("for");
    hs.add("Greeks");
    Iterator<String> hs1=hs.iterator();
    while(hs1.hasNext()) {
    System.out.print(hs1.next()+" ");
    }
	}

}
