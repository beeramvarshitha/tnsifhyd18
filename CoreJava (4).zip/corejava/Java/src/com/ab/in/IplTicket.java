package com.ab.in;


interface Stadiumticket{
	void ticket();
}
class RajivaGandhi implements Stadiumticket{
	public void ticket() {
		System.out.println("RajivaGandhi Stadium ticket is 20000");
	}
}


class NarendraModi implements Stadiumticket{
	public void ticket() {
		System.out.println("NarendraModi Stadium ticket is 5000");
	}
}


class EdenGarden implements Stadiumticket{
	public void ticket() {
		System.out.println("EdenGarden Stadium ticket is 10000");
	}
}
public class IplTicket {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Stadiumticket rg=new RajivaGandhi();
     rg.ticket();
     Stadiumticket nm=new NarendraModi();
     nm.ticket();
     Stadiumticket eg=new EdenGarden();
     eg.ticket();

	}

}
