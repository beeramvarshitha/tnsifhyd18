package com.ab.in;

import java.io.*;
import java.util.*;
public class VectorList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Vector<Integer> v=new Vector<Integer>();
      for(int i=1;i<=8;i++)
      v.add(i);
      System.out.println(v);
      v.remove(5);
      System.out.println(v);
      v.add(4,12);
      System.out.println(v);

           
	}

}
