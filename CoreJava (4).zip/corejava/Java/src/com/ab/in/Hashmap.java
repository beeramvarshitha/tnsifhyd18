package com.ab.in;

import java.util.*;


public class Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String>hm= new HashMap<Integer,String>();
        hm.put(202,"water");
        hm.put(204,"fire");
        hm.put(206,"air");
        System.out.println("Value of 1:"+hm.get(202));
        System.out.println("Value of 2:"+hm.get(204));
        System.out.println("Value of 3:"+hm.get(206));
        for(Map.Entry<Integer,String>h: hm.entrySet())
        System.out.print(h.getKey()+" "+h.getValue()+" ");	

	}
}