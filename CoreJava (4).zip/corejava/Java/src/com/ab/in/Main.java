package com.ab.in;

abstract  class Bike{
	abstract void rating ();
}
 class Honda extends Bike{
	void rating(){
		System.out.println("rating is 4.1");
	}
}

class Yamaha extends Bike{
	void rating(){
		System.out.println("rating is 4.5");
	}
}
class Royalenfield extends Bike{
	void rating(){
		System.out.println("rating is 4.8");
	}
}


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Bike b1=new Honda();
      b1.rating();
      Bike b2=new Yamaha();
      b2.rating();
      Bike b3=new Royalenfield();
      b3.rating();

	}

}
