package com.ab.in;

import java.io.*;
import java.util.*;
public class StackList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Stack<String> s= new Stack<String>();
	     s.push("Its");
	     s.push("my");
	     s.push("first");
	     s.push("java");
	     Iterator<String> s1=s.iterator();
	     while(s1.hasNext()) {
	     System.out.print(s1.next()+" ");
	     }
	     System.out.println();
	     s.pop();
	     s1=s.iterator();
	     while(s1.hasNext()) {
	     System.out.print(s1.next()+" ");
	     }
		}

}
