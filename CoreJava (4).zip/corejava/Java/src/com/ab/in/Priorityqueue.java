package com.ab.in;


import java.util.*;
public class Priorityqueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<Integer>pq=new PriorityQueue<Integer>();
        pq.add(435);
        pq.add(437);
        pq.add(459);
	    System.out.println(pq.peek());
	    System.out.println(pq.poll());
	    System.out.println(pq.peek());
	    System.out.println(pq.poll());
	    System.out.println(pq.peek());
	}

}
