package com.ab.in;

interface College{
	void branch();
}
public class LambdaExpression {
	public static void main(String[] args) {
		String b1="ECE";
		String b2="CSE";
		String b3="EEE";
		College cb=()->{
			 System.out.print("Branch"+" "+b1+" ");
			 System.out.print("Branch"+" "+b2+" ");
			 System.out.print("Branch"+" "+b3);
		};
		cb.branch();
	}

}
