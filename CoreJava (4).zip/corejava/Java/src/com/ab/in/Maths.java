package com.ab.in;

abstract class Shape{
	   int l=5;
	   int b=4;
	   int r=2;
	   abstract void area();
}
class Rectangle extends Shape{
	   void area() {
		   System.out.println("Area of Rectangle:"+ l*b);
	   }
}

class Triangle extends Shape{
	   void area() {
		   System.out.println("Area of Triangle:"+ (l*b)/2);
	   }
}
class Circle extends Shape{

	   void area() {
		   System.out.println("Area of Circle:"+ 3.14*r*r);
	   }   
}

public class Maths {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Shape s1=new Rectangle();
   s1.area();
   Shape s2=new Triangle();
   s2.area();
   Shape s3=new Circle();
   s3.area();

	}

}
