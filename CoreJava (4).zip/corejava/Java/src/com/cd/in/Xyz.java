package com.cd.in;

public class Xyz {
	static void result(int marks) {
		 if(marks<=36)
	throw new ArithmeticException("Failed in exam");
		 else
			 System.out.println("Passed in exam");
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      result(38);
	 try {
		 System.out.println("Varshitha"+" "+2/0);	 
	 }
  catch(ArithmeticException e) {
	  System.out.println("Reddy");
  }
	 finally {
		 System.out.println(" VarshithaReddy");
	 }
	 
	}

}
