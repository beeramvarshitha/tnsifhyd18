package com.cd.in;

public class Abc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      try {
    	  int[] i=new int[5];
    	  System.out.println(i[5]);
      }
      catch(ArithmeticException a) {
    	  System.out.println(a);
      }
      catch(ArrayIndexOutOfBoundsException b) {
    	  System.out.println(b);
      }
      
	}

}
