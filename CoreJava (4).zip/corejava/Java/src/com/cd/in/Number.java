package com.cd.in;

public class Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int i=5/0;
     try {
    	 System.out.println(i);
    	    
     }
     catch(ArithmeticException e){
    	 System.out.println("Reddy");
     }
	}

}
