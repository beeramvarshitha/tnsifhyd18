package com.in.java;

public class Student3 {


    private String Course;
	private int Attendance;
	private String fee;
	public String getCourse() {
		return  Course;
	}
	public void  setCourse(String  course) {
		 Course =  course;
	}
	public int getAttendance() {
		return Attendance;
	}
	public void setAttendance(int attendance) {
		Attendance = attendance;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String exam() {
		if( Course.equals("Btech") && Attendance >75 && fee.equals("paid")) {
			return "Issue The Hall Ticket";
		}
		else {
			return "Not Issue The Hall Ticket";
		}		
	}
}
