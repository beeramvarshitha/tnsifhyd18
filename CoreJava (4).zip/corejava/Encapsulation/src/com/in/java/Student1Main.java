package com.in.java;

public class Student1Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Student1 n1=new Student1();
      n1.setCourse("Btech");
      System.out.println(n1.getCourse());
      n1.setAttendance(75);
      System.out.println(n1.getAttendance());
      n1.setFee("Paid");
      System.out.println(n1.getFee());
      }

}
