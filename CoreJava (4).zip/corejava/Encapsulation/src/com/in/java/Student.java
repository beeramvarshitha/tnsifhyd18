package com.in.java;

public class Student {
	private String  Course;
	private int Attendance;
	public String fee;

}
