package com.in.java;

public class Student1 {
	private String  Course;
	private int Attendance;
	private String fee;
	public String getCourse() {
		return  Course;
	}
	public void setCourse(String  course) {
		 Course =  course;
	}
	public int getAttendance() {
		return Attendance;
	}
	public void setAttendance(int attendance) {
		Attendance = attendance;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}


}
