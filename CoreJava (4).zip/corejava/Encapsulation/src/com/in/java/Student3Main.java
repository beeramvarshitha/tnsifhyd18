package com.in.java;

public class Student3Main {
	public static void main(String[] args) {
		Student3 m1=new Student3();
		m1.setCourse("Btech");
		m1.setAttendance(55);
		m1.setFee("paid");
		System.out.println(m1.exam());
	}

}
