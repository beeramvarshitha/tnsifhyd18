package com.vb.re;
class Multilevel1{
	void singer() {
		System.out.println("DSP");
	}
	}
class Multilevel2 extends  Multilevel1 {
	void director() {
		System.out.println("Sukumar");
	}
}
public class Multilevel extends  Multilevel2 {
     void movie() {
    	 System.out.println("Pushpa");
     }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Multilevel m1=new  Multilevel();
		 m1.singer();
		  m1.director();
		  m1.movie();
	}

}
