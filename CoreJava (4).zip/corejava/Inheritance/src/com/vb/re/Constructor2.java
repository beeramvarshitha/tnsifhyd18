package com.vb.re;

public class Constructor2 {
	private String Course;
	private int Attendance;
	private String fee;
	
     public Constructor2(String Course,int Attendence,String fee) {
    	 this.Course=Course;
    	 this.Attendance=Attendence;
    	 this.fee=fee;
     }
     public String exam() {
			if( Course.equals("Btech") && Attendance >75 && fee.equals("Paid")) {
				return "Issue The Hall Ticket";
			}
			else {
				return "Not Issue The Hall Ticket";
			}		
		}

}
