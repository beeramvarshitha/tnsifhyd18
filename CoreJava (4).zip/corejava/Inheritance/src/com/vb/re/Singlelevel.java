package com.vb.re;
class Singlelevel1{
	void hero() {
		System.out.println("Allu Arjun");
	}
}
public class Singlelevel extends  Singlelevel1 {
	void heroine() {
		System.out.println("Mrunal Thakur");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Singlelevel s1=new Singlelevel();
    s1.hero();
    s1.heroine();
	}

}
