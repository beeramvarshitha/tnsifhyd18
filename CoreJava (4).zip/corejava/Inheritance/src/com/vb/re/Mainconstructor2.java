package com.vb.re;

public class Mainconstructor2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Constructor2 c2=new Constructor2("Btech", 56 , "Paid");
     System.out.println(c2.exam());
	}

}
