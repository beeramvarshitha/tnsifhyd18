package com.vb.re;

public class Mainconstructor1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor1 c1=new Constructor1();
		System.out.println(c1.exam());
	}

}
