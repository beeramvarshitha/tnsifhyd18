package com.vb.re;
   class Hierarchial1 {
	void superstar() {
		System.out.println("Super Star:"+"Mahesh Babu");
	}
}
   class Hierarchial2 extends Hierarchial1 {
    void energeticstar() {
	System.out.println("Energetic Star"+"Ram Pothineni");   
   }
   }
   class Hierarchial3 extends Hierarchial1{
	   void naturalstar() {
		   System.out.println("Natural Star:"+"Nani");
	   }
   }
public class Hierarchial extends Hierarchial1 {
     void powerstar() {
    	 System.out.println("Power Star:"+"Pavan Kalyan");

     }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hierarchial2 h1=new Hierarchial2();
	    h1.energeticstar();
		h1.superstar();
		
	}

}
