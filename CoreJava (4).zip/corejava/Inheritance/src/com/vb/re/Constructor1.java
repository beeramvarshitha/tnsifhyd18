package com.vb.re;

public class Constructor1 {
	 private String Course;
		private int Attendance;
		private String fee;
		
		
		public Constructor1() {
			 Course="Btech";
			 Attendance=82;
			 fee="Paid";
		}
		public String exam() {
			if( Course.equals("Btech") && Attendance >75 && fee.equals("Paid")) {
				return "Issue The Hall Ticket";
			}
			else {
				return "Not Issue The Hall Ticket";
			}		
		}

}
